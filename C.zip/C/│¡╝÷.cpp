#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main(){
	srand(time(NULL));
	int r=0;
	for (int i=0;i<10;i++){
		r=rand()%9;
		printf("%d\n",r);
	}
}
