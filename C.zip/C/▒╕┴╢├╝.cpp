#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

struct A{
	char test[20];
	int aa,bb,cc;
};
	
typedef struct{
	char test[20];
	int aa,bb,cc;
}B;//����ü 

int main(){
	struct A a={"test",1,2,3};
	B b={"test",1,2,3};
	printf("%s %d %d %d\n",a.test,a.aa,a.bb,a.cc);
	printf("%s %d %d %d\n",b.test,b.aa,b.bb,b.cc);
}
