#include <stdio.h>

int main()
{
	int n=100, m=0;
	
	char s[100];
	
	sprintf(s, "%d %d", n, m);
	
	printf("%s", s); 
}
