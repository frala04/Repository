#include<Windows.h>
#include<stdio.h>
 
int main(int argc, char *argv[]){
    INPUT_RECORD rc;
    DWORD        dw;
    int mouse_XY[2];
    COORD pos={0,0};
    
    SetConsoleMode(GetStdHandle(STD_OUTPUT_HANDLE), ENABLE_PROCESSED_INPUT | ENABLE_MOUSE_INPUT);
    while(1){
        
        ReadConsoleInput(GetStdHandle(STD_INPUT_HANDLE), &rc, 1, &dw); //�ڵ����� 
        mouse_XY[0] = rc.Event.MouseEvent.dwMousePosition.X; //X��ǥ 
        mouse_XY[1] = rc.Event.MouseEvent.dwMousePosition.Y; //Y��ǥ 

        FillConsoleOutputCharacter(GetStdHandle(STD_OUTPUT_HANDLE), ' ', 100 , pos, &dw); //ȭ�� �����         
        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), pos); //�ܼ���ǥ�̵� 
        printf("%d, %d\n", mouse_XY[0], mouse_XY[1]);       
        
    }
    return 0;
}
