#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <Windows.h>
#include <conio.h>

int in;
struct Mouse{
	int x, y, info, lr;
};
Mouse click(){
	Mouse mouse;
	INPUT_RECORD rc;
	DWORD input_count;
	HANDLE hIN = GetStdHandle(STD_INPUT_HANDLE);
	
	SetConsoleMode(hIN, ENABLE_EXTENDED_FLAGS | ENABLE_WINDOW_INPUT | ENABLE_MOUSE_INPUT);

	ReadConsoleInput(hIN, &rc, 1, &input_count);

	if (rc.EventType == MOUSE_EVENT){
		if (rc.Event.MouseEvent.dwButtonState & FROM_LEFT_1ST_BUTTON_PRESSED){
			mouse.x = rc.Event.MouseEvent.dwMousePosition.X;
			mouse.y = rc.Event.MouseEvent.dwMousePosition.Y;
			mouse.info = 1;
			mouse.lr = 1;
		}
		else if(rc.Event.MouseEvent.dwButtonState & RIGHTMOST_BUTTON_PRESSED){
            mouse.x = rc.Event.MouseEvent.dwMousePosition.X;
            mouse.y = rc.Event.MouseEvent.dwMousePosition.Y;
			mouse.info = 1;
			mouse.lr = 2;
		}
		else mouse.info = 0;
	}
	return mouse;
}
enum ColorNames{
	Black, Blue, Green, SkyBlue,
	Red, Pink, Orange, White,
	Gray, LightBlue, BrightGreen, Sky,
	BrightRed, BrightPink, BrightYellow, BrightWhite
};
void SetColor(int BackColor, int TextColor){
	HANDLE handle = GetStdHandle(STD_OUTPUT_HANDLE);
	SetConsoleTextAttribute(handle, (BackColor<<4) + TextColor);
}
void cursoroff(){
   CONSOLE_CURSOR_INFO cursorInfo={0,};
   cursorInfo.dwSize=1;
   cursorInfo.bVisible=FALSE;
   SetConsoleCursorInfo(GetStdHandle(STD_OUTPUT_HANDLE),&cursorInfo);
   srand(time(NULL));
}
void gotoxy(int y, int x){
	COORD pos={x, y};
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), pos);
}
void printmap(){
	system("mode con:cols=190 lines=49 | title �׸���");
	system("cls"); 
	cursoroff();
	int c=1,d=0;
	for(int j=0;j<49;j++){
		for(int k=0;k<96;k++){
			SetColor(BrightWhite,Black);
			printf("  ");
		}
	}
}
void draw(int x,int y){
	gotoxy(x+1,y*2+2);
	SetColor(Black,BrightWhite);
	printf("  ");
}
void eraser(int x, int y){
	SetColor(BrightWhite,Black);
	gotoxy(x,y*2+0);
	printf("      ");
	gotoxy(x+1,y*2);
	printf("      ");
	gotoxy(x+2,y*2);
	printf("      ");
}
void mouseInputProcess(){
	Mouse M={};
	while(1){
		M=click();
		if(M.info==1&&M.lr==1) draw(M.y-1,M.x/2-1);
		else if(M.info==1&&M.lr==2) eraser(M.y-1,M.x/2-1);
	}
}
int main(){
	printmap();
	mouseInputProcess();
}
