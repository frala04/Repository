#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <Windows.h>
#include <conio.h>

int mine[46][93];
int user[46][93];
int ex,end=1,f=450,chk,in;
struct Mouse{
	int x, y, info, lr;
};
Mouse click(){
	Mouse mouse;
	INPUT_RECORD rc;
	DWORD input_count;
	HANDLE hIN = GetStdHandle(STD_INPUT_HANDLE);
	
	SetConsoleMode(hIN, ENABLE_EXTENDED_FLAGS | ENABLE_WINDOW_INPUT | ENABLE_MOUSE_INPUT);

	ReadConsoleInput(hIN, &rc, 1, &input_count);

	if (rc.EventType == MOUSE_EVENT){
		if (rc.Event.MouseEvent.dwButtonState & FROM_LEFT_1ST_BUTTON_PRESSED){
			mouse.x = rc.Event.MouseEvent.dwMousePosition.X;
			mouse.y = rc.Event.MouseEvent.dwMousePosition.Y;
			mouse.info = 1;
			mouse.lr = 1;
		}
		else if(rc.Event.MouseEvent.dwButtonState & RIGHTMOST_BUTTON_PRESSED){
            mouse.x = rc.Event.MouseEvent.dwMousePosition.X;
            mouse.y = rc.Event.MouseEvent.dwMousePosition.Y;
			mouse.info = 1;
			mouse.lr = 2;
		}
		else mouse.info = 0;
	}
	if(mouse.x==0||mouse.x==94) mouse.info=0;
	if(mouse.y==0||mouse.y==47) mouse.info=0;
	return mouse;
}
enum ColorNames{
	Black, Blue, Green, SkyBlue,
	Red, Pink, Orange, White,
	Gray, LightBlue, BrightGreen, Sky,
	BrightRed, BrightPink, BrightYellow, BrightWhite
};
void SetColor(int BackColor, int TextColor){
	HANDLE handle = GetStdHandle(STD_OUTPUT_HANDLE);
	SetConsoleTextAttribute(handle, (BackColor<<4) + TextColor);
}
void cursoroff(){
   CONSOLE_CURSOR_INFO cursorInfo={0,};
   cursorInfo.dwSize=1;
   cursorInfo.bVisible=FALSE;
   SetConsoleCursorInfo(GetStdHandle(STD_OUTPUT_HANDLE),&cursorInfo);
   srand(time(NULL));
}
void gotoxy(int y, int x){
	COORD pos={x, y};
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), pos);
}
void genmap(){
	int r1=0,r2=0;
	for(int i=0; i<46; i++)
		for(int j=0; j<93; j++){
			mine[i][j]=0;
			user[i][j]=0;
		}
	
	srand(time(NULL));
	for(int i=0;i<450;i++){
		r1=rand()%46; r2=rand()%93;
		if(mine[r1][r2]==9)	i--;
		else{
			mine[r1][r2]=9;
			if(r1!=45&&mine[r1+1][r2]!=9) mine[r1+1][r2]++;
			if(r2!=92&&mine[r1][r2+1]!=9) mine[r1][r2+1]++;
			if(r1!=0&&mine[r1-1][r2]!=9) mine[r1-1][r2]++;
			if(r2!=0&&mine[r1][r2-1]!=9) mine[r1][r2-1]++;
			if((r1!=0&&r2!=0)&&mine[r1-1][r2-1]!=9) mine[r1-1][r2-1]++;
			if((r1!=0&&r2!=92)&&mine[r1-1][r2+1]!=9) mine[r1-1][r2+1]++;
			if((r1!=45&&r2!=92)&&mine[r1+1][r2+1]!=9) mine[r1+1][r2+1]++;
			if((r1!=45&&r2!=0)&&mine[r1+1][r2-1]!=9) mine[r1+1][r2-1]++;
		}
	}
	//user[1][1]=1;
	//mine[0][0]=9;
}
void startpoint(){
	for(int i=0; i<46; i++)
		for(int j=0; j<93; j++)
			if(mine[i][j]==0){
				gotoxy(i+1,j*2+2);
				if((i+j)%2) SetColor(Green,BrightWhite);
				else SetColor(BrightGreen,BrightWhite);
				printf("��");
				return; 
			}
}
void printmap(){
	system("cls"); 
	int c=1,d=0;
	for(int j=0;j<46;j++,c=1+j){
		puts("");
		printf("  ");
		for(int k=0;k<93;k++){
			c++;
			if(user[j][k]==0){
				if(c%2) SetColor(Green,BrightWhite);
				else SetColor(BrightGreen,BrightWhite);
				printf("  ");
			}
			else{
				SetColor(Black,BrightWhite);
				gotoxy(47,0);
				printf("ERROR : user array error");
				exit(1);
			}
		}
		SetColor(Black,BrightWhite);
		printf("  ");
	}
	gotoxy(47,0);
	printf("  4278���� 450��");
	startpoint();
}
void open(int x,int y){
	gotoxy(x+1,y*2+2);
	if(mine[x][y]==9){
		SetColor(BrightWhite,Red);
		printf("��");
	}
	else if(mine[x][y]==1){
		SetColor(BrightWhite,SkyBlue);
		printf("��");
	}
	else if(mine[x][y]==2){
		SetColor(BrightWhite,BrightGreen);
		printf("��");
	}
	else if(mine[x][y]==3){
		SetColor(BrightWhite,Red);
		printf("��");
	}
	else if(mine[x][y]==4){
		SetColor(BrightWhite,Pink);
		printf("��");
	}
	else if(mine[x][y]==5){
		SetColor(BrightWhite,BrightPink);
		printf("��");
	}
	else if(mine[x][y]==6){
		SetColor(BrightWhite,Orange);
		printf("��");
	}
	else if(mine[x][y]==7){
		SetColor(BrightWhite,Black);
		printf("��");
	}
	else if(mine[x][y]==8){
		SetColor(BrightWhite,Gray);
		printf("��");
	}
	else if(mine[x][y]==0){
		SetColor(BrightWhite,Black);
		printf("  ");
	}
}
void flag(int x, int y){
	gotoxy(x+1,y*2+2);
	if(user[x][y]!=1){
		if(user[x][y]==0){
			user[x][y]=2; 
			if((x+y)%2) SetColor(Green,BrightWhite);
			else SetColor(BrightGreen,BrightWhite);
			printf("��");
		}
		else if(user[x][y]==2){
			user[x][y]=0; 
			if((x+y)%2) SetColor(Green,BrightWhite);
			else SetColor(BrightGreen,BrightWhite);
			printf("  ");
		}
	}
}
int cango(int i,int j){
	int f=1;
	if(i<0||j<0) f=0;
	if(i>=46||j>=93) f=0;
	return f;
}
void processgame(int x,int y){
	if (cango(x,y)&&user[x][y]!=2) open(x,y);
	switch(mine[x][y]){
	case 1: case 2: case 3: case 4: case 5: case 6: case 7: case 8: case 9: 
		user[x][y]=1;
		break;
	}
	if(mine[x][y]==0&&(user[x][y]==0||user[x][y]==2)){
		user[x][y]=1;
		if (cango(x-1,y-1)) processgame(x-1,y-1);
		if (cango(x-1,y+1)) processgame(x-1,y+1);
		if (cango(x+1,y-1)) processgame(x+1,y-1);
		if (cango(x+1,y+1)) processgame(x+1,y+1);
		if (cango(x-1,y)) processgame(x-1,y);
		if (cango(x+1,y)) processgame(x+1,y);
		if (cango(x,y-1)) processgame(x,y-1);
		if (cango(x,y+1)) processgame(x,y+1);
	}
}
void check(int x, int y){
	int cnt;
	gotoxy(x+1,y*2+2);
	if(x!=45&&user[x+1][y]==2) cnt++;
	if(y!=92&&user[x][y+1]==2) cnt++;
	if(x!=0&&user[x-1][y]==2) cnt++;
	if(y!=0&&user[x][y-1]==2) cnt++;
	if((x!=0&&y!=0)&&user[x-1][y-1]==2) cnt++;
	if((x!=0&&y!=92)&&user[x-1][y+1]==2) cnt++;
	if((x!=45&&y!=92)&&user[x+1][y+1]==2) cnt++;
	if((x!=45&&y!=0)&&user[x+1][y-1]==2) cnt++;
	if(cnt==mine[x][y]){
		if(x!=45&&user[x+1][y]!=2) processgame(x+1,y);
		if(y!=92&&user[x][y+1]!=2) processgame(x,y+1);
		if(x!=0&&user[x-1][y]!=2) processgame(x-1,y);
		if(y!=0&&user[x][y-1]!=2) processgame(x,y-1);
		if((x!=0&&y!=0)&&user[x-1][y-1]!=2) processgame(x-1,y-1);
		if((x!=0&&y!=92)&&user[x-1][y+1]!=2) processgame(x-1,y+1);
		if((x!=45&&y!=92)&&user[x+1][y+1]!=2) processgame(x+1,y+1);
		if((x!=45&&y!=0)&&user[x+1][y-1]!=2) processgame(x+1,y-1);
	}
}
void endcheck(int n){
	ex=0;
	for(int i=0;i<46;i++)
		for(int j=0;j<93;j++)
			if(user[i][j]==0||user[i][j]==2) ex++;
	if(n){
		SetColor(Black,BrightWhite);
		gotoxy(47,0);
		printf("                  ");
		gotoxy(47,0);
		SetColor(Black,BrightWhite);
		printf("  %d���� 450��",ex);
	}
	if(ex==450){
		gotoxy(48,0);
		//exit(0);
		end--;
	}
}
void mouseInputProcess(){
	Mouse M={};
	while(end){
		chk=M.info;
		M=click();
		if((M.info==1&&chk==0)&&M.lr==1) processgame(M.y-1,M.x/2-1);
		else if(((M.info==1&&chk==0)&&M.lr==2)&&user[M.y-1][M.x/2-1]==1) check(M.y-1,M.x/2-1);
		else if(((M.info==1&&chk==0)&&M.lr==2)&&user[M.y-1][M.x/2-1]==0) flag(M.y-1,M.x/2-1);
		else if(((M.info==1&&chk==0)&&M.lr==2)&&user[M.y-1][M.x/2-1]==2) flag(M.y-1,M.x/2-1);
		endcheck(M.info);
	}
}
int updownselect(int x,int y,int a,int b){/*����x,y,a~b����*/ 
	int o;
	while(1){
		gotoxy(x,y);
		o=getch();
		printf(" ");
		if(o==72&&x>a) x--;
		else if(o==80&&x<b) x++;
		else if(o==13) break;
		gotoxy(x,y);
		printf(">");
	}
	return x;
}
void gamestart(){
	end=1; chk=0;
	system("cls");
	cursoroff();
	system("mode con:cols=190 lines=49 | title ����ã��_����");
	printf("\n\n\n\n\n\n\n              > ���� ����");
	printf("\n                ���� ����");
	in=updownselect(7,14,7,8);
	if(in==8) exit(0);
}
void gameend(){
	system("cls");
	printf("\n\n\n\n\n\n\n              > ���� �����");
	printf("\n                ���� ����");
	in=updownselect(7,14,7,8);
	if(in==8) exit(0);
}

int main(){
	while(1){
		gamestart();
		genmap();
		printmap();
		mouseInputProcess();
		Sleep(1000);
	}
}
