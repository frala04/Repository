#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <windows.h>
#include <conio.h>

bool chk=1;
int temp[500];
int han[500];
int k;

void gotoxy(int x, int y)
{
	COORD pos = { x, y };
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), pos);
}
bool chkDup(int* Arr, int* end, int target)
{
	for(int* i=Arr; i<end; i++)
	{
		if(*i==target)
			return true;
	}
	return false;
}
void draw(int* Arr, int size)
{
	for(int* i=Arr; i<Arr+size; i++)
		do {
			*i=rand()%size;
		} while(chkDup(Arr, i, *i));
}


const char choseong[19]={0b10100001, 0b10100010, 0b10100100, 0b10100111, 0b10101000, 0b10101001, 0b10110001, 0b10110010, 0b10110011, 0b10110101, 0b10110110, 0b10110111, 0b10111000, 0b10111001, 0b10111010, 0b10111011, 0b10111100, 0b10111101, 0b10111110};
const unsigned short ja_eum[19]={0b1011000010100001, 0b1011000111101110, 0b1011001110101010, 0b1011010011011001, 0b1011010111111011, 0b1011011011110011, 0b1011100010110110, 0b1011100111011001, 0b1011101011111100, 0b1011101111100111, 0b1011110111001110, 0b1011111011000110, 0b1100000011011010, 0b1100001010100101, 0b1100001011110111, 0b1100010010101011, 0b1100010110111000, 0b1100011011000100, 0b1100011111001111};

enum jaeum{
	ga, gga, na, da, dda, la,
	ma, ba, bba, sa, ssa, a,
	ja, jja, cha, ka, ta, pa, ha
};

void conversion(char* s, int cnt)
{
	unsigned short size;
	unsigned char s0, s1;
	
	if(chk)
	{
		memset(han, 0, sizeof(int)*500);
		k=0;
		
		for(int i=0; s[i]!=NULL; i++)
		{
			s0=s[i], s1=s[i+1];
			
			if((s1<=254 && s1>=161) && (s0>=176 && s0<=200))
			{
				han[k++]=i;
				i++;
			}
		}
		
		chk=0;
		
		memset(temp, 0, sizeof(int)*500);
		draw(temp, k);
	
		for(int i=0; i<k; i++)
			temp[i]=han[temp[i]];
		
		for(int i=0; i<k; i++)
			han[i]=temp[i];
	}
	
	int z=k-cnt;
	
	if(k>5) z=k-(cnt*(k/5));
	
	for(int i=0; i<z; i++)
	{
		s0=s[han[i]], s1=s[han[i]+1];
		size=s0<<8|s1;
		
		s[han[i]]=164;
		
		for(int j=ha; j>=ga; j--)
		{
			if(size>=ja_eum[j])
			{
				s[han[i]+1]=choseong[j];
				break;
			}
		}
	}
}

int main()
{
	system("mode con:cols=64 lines=16 | title ��Ǯ�� ����");
	
	srand(time(NULL));
	
	int cur=1, total=0, cnt=0, entire=0;
	int pass=0, ignore=0;
	char m[100][500];
	char string_conver[500];
	char input[500];
	
	FILE* fread = fopen("words.txt", "r");
	if(fread == NULL)
	{
		printf("Please make words.txt using ANSI encoding");
		return 0;
	}
	
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), (0xF<<4)|0x0);
	
	for(entire=0; !feof(fread); entire++)
		fgets(m[entire], 500, fread);
	
	int random[entire];
	draw(random, entire);
	
	for(int j=0; j<entire; j++)
	{
		int k=random[j];	
		m[k][strlen(m[k])-1]=='\n'?m[k][strlen(m[k])-1]=NULL:0;
		
		char* p;
		
		for(int i=0; ; i++)
		{
			if(m[k][i]==':')
			{
				p=m[k]+i+2;
				m[k][i-1]=NULL;
				break;
			}
		}
		
		while(1)
		{
			strcpy(string_conver, p);
			conversion(string_conver, cnt-1);
			
			system("cls");
			printf("%s? (%d/%d) (%d/%d)\n", m[k], cur, entire, ++cnt, total+cnt+1);
			
			if(cnt>1) printf("%s\n", string_conver);
			
			fgets(input, 3000, stdin);
			input[strlen(input)-1]=NULL;
			
			if(!strcmp(input, p))
			{
				pass++;
				cur++;
				total+=cnt;
				cnt=0;
				chk=1;
				break;
			}
			else if(input[0]=='n' && input[1]==NULL)
			{
				ignore++;
				cur++;
				total+=cnt;
				cnt=0;
				chk=1;
				break;
			}
		}
	}
	system("cls");
	printf("congratulation!\ntotal %d tries.\npass : %d\nignore : %d\nfail : %d\n", total, pass, ignore, total-pass-ignore);
	getch();
	
	fclose(fread);
}
