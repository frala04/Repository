int print(int (*x)[15]);
int updownselect(int x,int y,int a,int b);
void start_ment();
int start_select();
int end_ment(int c,int m,int n); 
int end_select();
int pause_ment();
void info_ment();
