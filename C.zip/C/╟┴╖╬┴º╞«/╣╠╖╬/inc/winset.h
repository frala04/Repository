void cursoroff();
void color(int n);
void gotoxy(int x,int y);
void winset(int x);
