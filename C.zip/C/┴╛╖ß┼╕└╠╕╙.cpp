#include <stdio.h>
#include <string.h>
#include <time.h>
#include <conio.h>
#include <Windows.h>

bool ShutdownWay;
int num[4]={};

struct Mouse{
	int x, y, info;
};

Mouse click()
{
	Mouse mouse;
	INPUT_RECORD input_record;
	DWORD input_count;
	HANDLE hIN = GetStdHandle(STD_INPUT_HANDLE);
	
	SetConsoleMode(hIN, ENABLE_EXTENDED_FLAGS | ENABLE_WINDOW_INPUT | ENABLE_MOUSE_INPUT);

	ReadConsoleInput(hIN, &input_record, 1, &input_count);

	if (input_record.EventType == MOUSE_EVENT)
	{
		if (input_record.Event.MouseEvent.dwButtonState & FROM_LEFT_1ST_BUTTON_PRESSED)
		{
			mouse.x = input_record.Event.MouseEvent.dwMousePosition.X;
			mouse.y = input_record.Event.MouseEvent.dwMousePosition.Y;
			mouse.info = 1;
		}
		else
		{
			mouse.info = 0;
		}
	}
	
	return mouse;
}

enum ColorNames{
	Black, Blue, Green, SkyBlue,
	Red, Pink, Orange, White,
	Gray, LightBlue, BrightGreen, Sky,
	BrightRed, BrightPink, BrightYellow, BrightWhite
};

void SetColor(int BackColor, int TextColor)
{
	HANDLE handle = GetStdHandle(STD_OUTPUT_HANDLE);
	SetConsoleTextAttribute(handle, (BackColor<<4) + TextColor);
}

void cursorInfo(bool info)
{
	CONSOLE_CURSOR_INFO cursorinfo={};
	cursorinfo.dwSize=1;
	cursorinfo.bVisible=info?TRUE:FALSE;
	SetConsoleCursorInfo(GetStdHandle(STD_OUTPUT_HANDLE), &cursorinfo);
}
 
void gotoxy(int y, int x)
{
	COORD pos={x, y};
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), pos);
}

void printUI()
{
	SetColor(BrightWhite, Black);
	
	system("cls");
	
	gotoxy(2, (30-strlen("���� ���� Ÿ�̸�"))/2);
	printf("���� ���� Ÿ�̸�");
	
	gotoxy(5, 3);
	printf("�� ");
	SetColor(White, Black); 
	printf("  0");
	SetColor(BrightWhite, Black);
	printf("�ð� ");
	SetColor(White, Black);
	printf("  0");
	SetColor(BrightWhite, Black);
	printf("�� �� ����");
	
	gotoxy(7, 3);
	printf("�� ");
	SetColor(White, Black); 
	printf("  0");
	SetColor(BrightWhite, Black);
	printf("��   ");
	SetColor(White, Black);
	printf("  0");
	SetColor(BrightWhite, Black); 
	printf("�п�  ����");
	
	gotoxy(10, (30-strlen("���� ����"))/2);
	SetColor(White, Black);
	printf("���� ����");
	
	gotoxy(12, (30-strlen("���� ���"))/2);
	SetColor(White, Black);
	printf("���� ���");
	
	gotoxy(14, 0);
	SetColor(BrightWhite, Black);
	printf("%30s", "Made by Napna");
}

void SetProgramOption()
{
	system("mode con:cols=30 lines=15 | title ���� ���� Ÿ�̸�");
	
	printUI();
	
	gotoxy(5, 8);
}

int mouseInputProcess()
{
	Mouse M=click();
	
	if(M.info==1)
	{
		if((M.x>=6 && M.x<=8) && (M.y==5))
		{
			gotoxy(5, 8);
			cursorInfo(true);
			return 1;
		}
		else if((M.x>=14 && M.x<=16) && (M.y==5))
		{
			gotoxy(5, 16);
			cursorInfo(true);
			return 2;
		}
		else if((M.x>=6 && M.x<=8) && (M.y==7))
		{
			gotoxy(7, 8);
			cursorInfo(true);
			return 3;
		}
		else if((M.x>=14 && M.x<=16) && (M.y==7))
		{
			gotoxy(7, 16);
			cursorInfo(true);
			return 4;
		}
		else
		{
			cursorInfo(false);
			
			if((M.x>=3 && M.x<=4) && (M.y==5))
			{
				ShutdownWay=0;
				SetColor(BrightWhite, Black);
				gotoxy(5, 3);
				printf("��");
				gotoxy(7, 3);
				printf("��");
				
				return 0;
			}
			else if((M.x>=3 && M.x<=4) && (M.y==7))
			{
				ShutdownWay=1;
				SetColor(BrightWhite, Black);
				gotoxy(5, 3);
				printf("��");
				gotoxy(7, 3);
				printf("��");
				
				return 0;
			}
			else if((M.x>=10 && M.x<=18) && (M.y==10))
			{
				if(ShutdownWay==0)
				{
					char tmp[30]={};
					
					sprintf(tmp, "shutdown -s -t %d", num[0]*3600+num[1]*60);
					
					SetColor(BrightWhite, Black);
					system("cls");
					system(tmp);
					printf("\n�ƹ� Ű�� ������\nó�� ȭ������ ���ư��ϴ�.");
					getch();
					
					M.x=0;
				
					for(int i=0; i<4; i++)
						num[i]=0;
						
					printUI();
				}
				else
				{
					time_t timer = time(NULL);
	
					struct tm* t = localtime(&timer);
					
					if(num[2]<t->tm_hour)
						num[2]+=24;
					if(num[3]<t->tm_min)
					{
						num[2]--;
						num[3]+=60;
					}
					
					char tmp[30]={};
					
					sprintf(tmp, "shutdown -s -t %d", (num[2]-t->tm_hour)*3600+(num[3]-t->tm_min)*60-t->tm_sec);
					
					SetColor(BrightWhite, Black);
					system("cls");
					system(tmp);
					printf("\n�ƹ� Ű�� ������\nó�� ȭ������ ���ư��ϴ�.");
					getch();
					
					M.x=0;
					ShutdownWay=0;
					
					for(int i=0; i<4; i++)
						num[i]=0;
						
					printUI();
				}
			}
			else if((M.x>=10 && M.x<=18) && (M.y==12))
			{
				SetColor(BrightWhite, Black);
				system("cls");
				system("shutdown -a");
				printf("\n�ƹ� Ű�� ������\nó�� ȭ������ ���ư��ϴ�.");
				getch();
				
				M.x=0;
				
				for(int i=0; i<4; i++)
					num[i]=0;
				
				printUI();
				
				return 0;
			}
		}
	}
	return -1;
}

int main()
{
	SetProgramOption();
	
	int result=1;
	int keyInput=0;
	
	while(1)
	{
		int t=mouseInputProcess();
		
		if(t>=0) result=t;
		
		if(result>0)
		{
			keyInput=-2;
		
			if((GetAsyncKeyState('0') & 0x0001) | (GetAsyncKeyState(VK_NUMPAD0) & 0x0001)) keyInput=0;
			else if((GetAsyncKeyState('1') & 0x0001) | (GetAsyncKeyState(VK_NUMPAD1) & 0x0001)) keyInput=1;
			else if((GetAsyncKeyState('2') & 0x0001) | (GetAsyncKeyState(VK_NUMPAD2) & 0x0001)) keyInput=2;
			else if((GetAsyncKeyState('3') & 0x0001) | (GetAsyncKeyState(VK_NUMPAD3) & 0x0001)) keyInput=3;
			else if((GetAsyncKeyState('4') & 0x0001) | (GetAsyncKeyState(VK_NUMPAD4) & 0x0001)) keyInput=4;
			else if((GetAsyncKeyState('5') & 0x0001) | (GetAsyncKeyState(VK_NUMPAD5) & 0x0001)) keyInput=5;
			else if((GetAsyncKeyState('6') & 0x0001) | (GetAsyncKeyState(VK_NUMPAD6) & 0x0001)) keyInput=6;
			else if((GetAsyncKeyState('7') & 0x0001) | (GetAsyncKeyState(VK_NUMPAD7) & 0x0001)) keyInput=7;
			else if((GetAsyncKeyState('8') & 0x0001) | (GetAsyncKeyState(VK_NUMPAD8) & 0x0001)) keyInput=8;
			else if((GetAsyncKeyState('9') & 0x0001) | (GetAsyncKeyState(VK_NUMPAD9) & 0x0001)) keyInput=9;
			else if(GetAsyncKeyState(VK_BACK) & 0x0001) keyInput=-1;
			
			if(keyInput!=-2)
			{
				if(keyInput>=0)
				{
					if(num[result-1]<10)
						num[result-1]=num[result-1]*10+keyInput;
					
					if(result==3)
					{
						if(num[result-1]>23)
						{
							num[result-1]=23;
						}
					}
					else if(result==2||result==4)
					{
						if(num[result-1]>59)
						{
							num[result-1]=59;
						}
					}
				}
				else if(keyInput==-1)
				{
					num[result-1]/=10;
				}
				cursorInfo(false);
			
				if(result==1)
					gotoxy(5, 6);
				else if(result==2)
					gotoxy(5, 14);
				else if(result==3)
					gotoxy(7, 6);
				else if(result==4)
					gotoxy(7, 14);
				
				SetColor(White, Black);
				printf("%3d", num[result-1]);
				
				if(result==1)
					gotoxy(5, 8);
				else if(result==2)
					gotoxy(5, 16);
				else if(result==3)
					gotoxy(7, 8);
				else if(result==4)
					gotoxy(7, 16);
				
				cursorInfo(true);
			}
		}
	}
}
